﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ClientTaxiUI2 {
    public partial class Form1 : Form {

        Client client = new Client();

        public Form1() {
            InitializeComponent();
           // InitializeTimePicker();
            client.Start();
        }
       // private DateTimePicker timePicker;

       /* private void InitializeTimePicker() {
            timePicker = new DateTimePicker();
            timePicker.Format = DateTimePickerFormat.Time;
            timePicker.ShowUpDown = true;
            timePicker.Location = new Point(10, 10);
            timePicker.Width = 100;
            timePicker.Size = new Size(424, 20);
            Controls.Add(timePicker);
        }*/

        private void Order_Click(object sender, EventArgs e) {
            client.SendString("101 " + NameBox.Text + "\r\n");
            client.SendString("102 " + PhoneBox.Text + "\r\n");
            client.SendString("103 " + paramBox.Text + "\r\n");
            client.SendString("104 " + ValueBox.Text );
            
        }

        private void NameBox_TextChanged(object sender, EventArgs e)
        {

        }
        private void paramBoxBox_TextChanged(object sender, EventArgs e)
        {

        }
        private void ValueBox_TextChanged(object sender, EventArgs e)
        {

        }
        



        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void label1_Click_3(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Paramlabel_Click(object sender, EventArgs e)
        {

        }

        private void Valuelabel_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void OnSizeChanged(object sender, EventArgs e)
        {
            Panel panel = sender as Panel;
            bool narrow = panel.Width < panel.Height;
            int size = narrow ? panel.Width : panel.Height;
            panel1.Size = new Size(size, size);
            panel1.Location = new Point
            {
                X = narrow ? 0 : panel.Width / 2 - size / 2,
                Y = narrow ? panel.Height / 2 - size / 2 : 0
            };
        }

    }
}
