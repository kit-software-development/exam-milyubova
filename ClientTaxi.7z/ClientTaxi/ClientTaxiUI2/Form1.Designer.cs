﻿namespace ClientTaxiUI2 {
    partial class Form1 {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent() {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.ValueBox = new System.Windows.Forms.TextBox();
            this.Valuelabel = new System.Windows.Forms.Label();
            this.paramBox = new System.Windows.Forms.TextBox();
            this.Order = new System.Windows.Forms.Button();
            this.PhoneBox = new System.Windows.Forms.TextBox();
            this.NameBox = new System.Windows.Forms.TextBox();
            this.Paramlabel = new System.Windows.Forms.Label();
            this.Phonelabel = new System.Windows.Forms.Label();
            this.NameLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.ValueBox);
            this.panel1.Controls.Add(this.Valuelabel);
            this.panel1.Controls.Add(this.paramBox);
            this.panel1.Controls.Add(this.Order);
            this.panel1.Controls.Add(this.PhoneBox);
            this.panel1.Controls.Add(this.NameBox);
            this.panel1.Controls.Add(this.Paramlabel);
            this.panel1.Controls.Add(this.Phonelabel);
            this.panel1.Controls.Add(this.NameLabel);
            this.panel1.Location = new System.Drawing.Point(4, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(305, 346);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(69, 161);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "1 - minutes, 2 - km";
            // 
            // ValueBox
            // 
            this.ValueBox.Location = new System.Drawing.Point(69, 230);
            this.ValueBox.Name = "ValueBox";
            this.ValueBox.Size = new System.Drawing.Size(169, 20);
            this.ValueBox.TabIndex = 9;
            // 
            // Valuelabel
            // 
            this.Valuelabel.AutoSize = true;
            this.Valuelabel.Location = new System.Drawing.Point(68, 214);
            this.Valuelabel.Name = "Valuelabel";
            this.Valuelabel.Size = new System.Drawing.Size(34, 13);
            this.Valuelabel.TabIndex = 8;
            this.Valuelabel.Text = "Value";
            this.Valuelabel.Click += new System.EventHandler(this.Valuelabel_Click);
            // 
            // paramBox
            // 
            this.paramBox.Location = new System.Drawing.Point(69, 177);
            this.paramBox.Name = "paramBox";
            this.paramBox.Size = new System.Drawing.Size(169, 20);
            this.paramBox.TabIndex = 7;
            this.paramBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Order
            // 
            this.Order.Location = new System.Drawing.Point(67, 273);
            this.Order.Name = "Order";
            this.Order.Size = new System.Drawing.Size(75, 23);
            this.Order.TabIndex = 1;
            this.Order.Text = "Order";
            this.Order.UseVisualStyleBackColor = true;
            this.Order.Click += new System.EventHandler(this.Order_Click);
            // 
            // PhoneBox
            // 
            this.PhoneBox.Location = new System.Drawing.Point(69, 108);
            this.PhoneBox.Name = "PhoneBox";
            this.PhoneBox.Size = new System.Drawing.Size(169, 20);
            this.PhoneBox.TabIndex = 6;
            // 
            // NameBox
            // 
            this.NameBox.Location = new System.Drawing.Point(69, 55);
            this.NameBox.Name = "NameBox";
            this.NameBox.Size = new System.Drawing.Size(169, 20);
            this.NameBox.TabIndex = 5;
            this.NameBox.TextChanged += new System.EventHandler(this.NameBox_TextChanged);
            // 
            // Paramlabel
            // 
            this.Paramlabel.AutoSize = true;
            this.Paramlabel.Location = new System.Drawing.Point(69, 144);
            this.Paramlabel.Name = "Paramlabel";
            this.Paramlabel.Size = new System.Drawing.Size(37, 13);
            this.Paramlabel.TabIndex = 2;
            this.Paramlabel.Text = "Param";
            this.Paramlabel.Click += new System.EventHandler(this.Paramlabel_Click);
            // 
            // Phonelabel
            // 
            this.Phonelabel.AutoSize = true;
            this.Phonelabel.Location = new System.Drawing.Point(68, 92);
            this.Phonelabel.Name = "Phonelabel";
            this.Phonelabel.Size = new System.Drawing.Size(38, 13);
            this.Phonelabel.TabIndex = 1;
            this.Phonelabel.Text = "Phone";
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Location = new System.Drawing.Point(68, 39);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(35, 13);
            this.NameLabel.TabIndex = 0;
            this.NameLabel.Text = "Name";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(311, 349);
            this.Controls.Add(this.panel1);
            this.MinimumSize = new System.Drawing.Size(327, 388);
            this.Name = "Form1";
            this.Text = "Taxi";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label Phonelabel;
        private System.Windows.Forms.Label Paramlabel;
        private System.Windows.Forms.TextBox NameBox;
        private System.Windows.Forms.TextBox PhoneBox;
        private System.Windows.Forms.Button Order;
        private System.Windows.Forms.TextBox paramBox;
        private System.Windows.Forms.TextBox ValueBox;
        private System.Windows.Forms.Label Valuelabel;
        private System.Windows.Forms.Label label1;
    }
}

